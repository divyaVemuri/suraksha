import 'package:flutter/material.dart';
import 'package:pin_entry_text_field/pin_entry_text_field.dart';
import 'package:suraksha/Register.dart';

class SetMpin extends StatefulWidget {
  @override
  _SetMpinState createState() => _SetMpinState();
}

class _SetMpinState extends State<SetMpin>{
  String num1, num2;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Stack(
            children: <Widget>[
              Container(
                height: 700,
                color: Color.fromRGBO(255, 246, 246, 1),
              ),
              ClipPath(
                clipper: ClippingClass(),
                child: Container(

                  color:Color.fromRGBO(255, 236, 236, 1),
                  height: 350,
                  width: MediaQuery.of(context).size.width,
                ),
              ),

              form(),
            ],
          ),
      ),
      )
    );
  }

  Widget form(){
    return Container(
      padding: EdgeInsets.all(30),
        child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        _mpinLabel,
        _mpinInputLabel,
        _mpin(),
        _mpinConfirmLabel,
        _mpinConfirm()
      ],
    )
    );
  }

  Widget _sizedBox({double height, double width}) {
    return SizedBox(
      height: height,
      width: width,
    );
  }

  get _mpinLabel {
    return Align(
      alignment: Alignment.topLeft,
      child: Container(
        margin: EdgeInsets.only(top: 49),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              "Set",
              textAlign: TextAlign.left,
              style: TextStyle(
                color: Color.fromARGB(255, 46, 47, 48),
                fontFamily: "",
                fontWeight: FontWeight.bold,
                fontSize: 25,
                letterSpacing: 0.05407,
              ),
            ),
            Text(
              "M PIN",
              textAlign: TextAlign.left,
              style: TextStyle(
                color: Color.fromARGB(255, 46, 47, 48),
                fontFamily: "",
                fontWeight: FontWeight.bold,
                fontSize: 25,
                letterSpacing: 0.05407,
              ),
            ),
          ],
        ),
      ),
    );
  }

  get _mpinInputLabel {
    return Container(
//      margin: EdgeInsets.only(top: 10),
      padding: EdgeInsets.fromLTRB(10,30,10,0),
      child: Text(
        "Input your preferred 4 digit MPIN",
        textAlign: TextAlign.left,
        style: TextStyle(
          color: Color.fromARGB(255, 46, 47, 48),
          fontFamily: "",
          fontWeight: FontWeight.w400,
          fontSize: 16,
          letterSpacing: 0.05407,
        ),
      ),
    );
  }

  get _mpinConfirmLabel {
    return Container(
//      margin: EdgeInsets.only(top: 30),
      padding: EdgeInsets.fromLTRB(10,30,10,0),

      child: Text(
        "Confirm your PIN",
        textAlign: TextAlign.left,
        style: TextStyle(
          color: Color.fromARGB(255, 46, 47, 48),
          fontFamily: "",
          fontWeight: FontWeight.w400,
          fontSize: 16,
          letterSpacing: 0.05407,
        ),
      ),
    );
  }

  Widget _mpin() {
    return PinEntryTextField(
        showFieldAsBox: false,
        onSubmit: (value) {
          num1 = value;
          print('num1=' + num1);
        });
  }

  Widget _mpinConfirm() {
//    getHttp();
    return PinEntryTextField(
        showFieldAsBox: false,
        onSubmit: (value) {
          num2 = value;
          print('num2=' + num2);
          if (num1 == num2) {
            Navigator.pushNamed(context, '/mpinSuccessful');
          }
        });
  }
//  void getHttp() async {
//    try {
//      Response response = await Dio().get("http://34.93.103.211/lms/api/roles");
//      print('resposne says '+response.toString());
//    } catch (e) {
//      print(e);
//    }
//  }

}

class ClippingClass extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    var path = Path();
    path.lineTo(0, size.height );
    path.quadraticBezierTo(
        size.width / 8, size.height / 2, size.width / 2, size.height / 2);
//    path.close();
    path.quadraticBezierTo(
        (size.width * 7) / 8, size.height / 2, size.width, 80);

    path.lineTo(size.width, 0);

    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) {
    // TODO: implement shouldReclip
    return false;
  }
}
