import 'package:flutter/material.dart';
import 'package:suraksha/values/gradients.dart';

class Register extends StatefulWidget {
  @override
  _RegisterState createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Stack(
            children: <Widget>[
              Container(
                height: 700,
                color: Color.fromRGBO(255, 246, 246, 1),
              ),
              ClipPath(
                clipper: ClippingClass(),
                child: Container(

                  color:Color.fromRGBO(255, 236, 236, 1),
                  height: 350,
                  width: MediaQuery.of(context).size.width,
                ),
              ),

              form(),
            ],
          ),
        ),
      ),
    );
  }

  Widget form() {
    return Container(
      padding: EdgeInsets.fromLTRB(20,30, 20, 20),

      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          skipButton(),
          caption(),
          _inputFields,
          SizedBox(height: 40,),
          _signUpRow,
          SizedBox(height: 10,),
          _loginLink(context)
        ],
      ),
    );
  }

  Widget skipButton() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: <Widget>[
        InkResponse(
          child: Container(
            child: Text(
              'Skip',
              style: TextStyle(
                  color: Color.fromRGBO(231, 10, 47, 1),
                  letterSpacing: 0.2,
                  fontWeight: FontWeight.w500,
                  fontSize: 18.0,
                  decoration: TextDecoration.underline),
            ),
          ),
          onTap: () {},
        ),
      ],
    );
  }

  Widget caption(){
    return Container(
      padding: EdgeInsets.all(10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text('Create',
          style: TextStyle(
            fontSize: 26,
            fontWeight: FontWeight.w800
          ),),
          Text('Account',style: TextStyle(
              fontSize: 26,
              fontWeight: FontWeight.w800
          ),)
        ],
      ),
    );
  }
}

get _inputFields{
  return Container(
    padding: EdgeInsets.all(20),
    child: Column(
      children: <Widget>[
        TextFormField(

          keyboardType: TextInputType.text,
//        autovalidate: _validate,
//        validator: validateName,
//        controller: firstNameController,
          decoration: InputDecoration(
            contentPadding: EdgeInsets.fromLTRB(0,5,0,5),
            labelText: "Name",
            labelStyle: TextStyle(
                color: Colors.grey[500],
                fontSize: 15.0,
                letterSpacing: 1.0),
            enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(width:0.5,color: Colors.grey[400]),
            ),
//            focusedBorder: UnderlineInputBorder(
//              borderSide: BorderSide(color: Colors.cyan),
//            ),
          ),
        ),

        SizedBox(
          height: 40.0,
        ),

        TextFormField(
          keyboardType: TextInputType.text,
//        autovalidate: _validate,
//        validator: validateName,
//        controller: lastNameController,
          decoration: InputDecoration(
            contentPadding: EdgeInsets.fromLTRB(0,5,0,5),
            labelText: "Mobile",
            labelStyle: TextStyle(
                color: Colors.grey[500],
                fontSize: 15.0,
                letterSpacing: 1.0),
            enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(width:0.5,color: Colors.grey[400]),
            ),
          ),
        ),

        SizedBox(
          height: 40.0,
        ),

        TextFormField(
          keyboardType: TextInputType.number,
//        autovalidate: _validate,
//        validator: validateMobile,
//        controller: numberController,
//          maxLength: 10,
          decoration: InputDecoration(
            contentPadding: EdgeInsets.fromLTRB(0,5,0,5),
            labelText: "Email",
            labelStyle: TextStyle(
                color: Colors.grey[500],
                fontSize: 15.0,
                letterSpacing: 1.0),
            enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(width:0.5,color: Colors.grey[400]),
            ),
          ),
        ),

        SizedBox(
          height: 40.0,
        ),

        TextFormField(
          keyboardType: TextInputType.text,
//        autovalidate: _validate,
//        validator: validateEmail,
//        controller: emailController,
          decoration: InputDecoration(
            contentPadding: EdgeInsets.fromLTRB(0,5,0,5),
            labelText: "Password",
            labelStyle: TextStyle(
                color: Colors.grey[500],
                fontSize: 15.0,
                letterSpacing: 1.0),
            enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(width:0.5,color: Colors.grey[400]),
            ),
          ),
        ),
      ],
    ),
  );
}

get _signUpRow{
  return Container(
    padding: EdgeInsets.all(20),

    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: <Widget>[
        Text('Sign Up',
          style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.w800
          ),)
        ,
        Container(
          height: 55,
          width: 55,
          decoration: BoxDecoration(
//                    borderRadius: BorderRadius.circular(20),
            gradient: Gradients.redGradient,
            shape: BoxShape.circle,
          ),
          child: IconButton(
//                    iconSize: 50,
            icon: Icon(
              Icons.arrow_forward,
              color: Colors.white,
              size: 40,
            ),
          ),
        )
      ],
    ),
  );
}

Widget _loginLink(BuildContext context){
  return Container(
    padding: EdgeInsets.all(20),
    child: InkResponse(
      child: Text(
        'Login ',
        style:
        TextStyle(fontWeight: FontWeight.bold, fontSize: 18,decoration: TextDecoration.underline),
      ),
      onTap: () {
        Navigator.pop(context);
      },
    ),
  );
}

class ClippingClass extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    var path = Path();
    path.lineTo(0, size.height );
    path.quadraticBezierTo(
        size.width / 8, size.height / 2, size.width / 2, size.height / 2);
//    path.close();
    path.quadraticBezierTo(
        (size.width * 7) / 8, size.height / 2, size.width, 80);

    path.lineTo(size.width, 0);

    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) {
    // TODO: implement shouldReclip
    return false;
  }
}
