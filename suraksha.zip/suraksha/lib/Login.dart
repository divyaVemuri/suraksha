import 'package:flutter/material.dart';
import 'package:suraksha/values/gradients.dart';

class Login extends StatefulWidget {
  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Container(
            padding: EdgeInsets.only(top: 30),
            decoration: BoxDecoration(
//            color: Color.fromRGBO(231, 10, 37, 2),
                gradient: Gradients.redGradient),
            child: Column(
              children: <Widget>[title(), inputForm()],
            ),
          ),
        ),
      ),
    );
  }

  Widget title() {
    return Container(
      alignment: Alignment.center,
      child: (Column(
        children: <Widget>[
          Text(
            'Suraksha',
            style: TextStyle(
//              backgroundColor: Colors.grey,
                color: Colors.white,
                fontSize: 40,
                fontWeight: FontWeight.w900),
          ),
          Text(
            'Diagnostics',
            style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.w900,
                letterSpacing: 5),
          ),
          SizedBox(
            height: 0,
          ),
          Container(
//            color: Colors.grey,
              height: 190,
              width: 250,
              child: Image.asset(
                "assets/login.png",
                fit: BoxFit.contain,
              )),
        ],
      )),
    );
  }

  Widget inputForm() {
    return Container(
      padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(40), topRight: Radius.circular(40)),
          color: Colors.white),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            padding: EdgeInsets.only(left: 40, right: 40, bottom: 30),
            child: TextFormField(
              keyboardType: TextInputType.number,
//        maxLength: 10,
//        validator: validateMobile,
//        controller: numberController,
              decoration: InputDecoration(
                labelText: "Mobile",
                labelStyle: TextStyle(
                    color: Colors.grey[500],
                    fontSize: 15.0,
                    letterSpacing: 1.0),
                border: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.red)),
//              hintText: 'Enter a search term'
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.only(left: 40, right: 40, bottom: 30),
            child: TextFormField(
              keyboardType: TextInputType.number,
//        maxLength: 10,
//        validator: validateMobile,
//        controller: numberController,
              decoration: InputDecoration(
                labelText: "Password",
                labelStyle: TextStyle(
                    color: Colors.grey[500],
                    fontSize: 15.0,
                    letterSpacing: 1.0),
                border: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.red)),
//              hintText: 'Enter a search term'
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.only(left: 40, right: 40, bottom: 30),
            child: InkResponse(
              child: Text(
                'Login with OTP',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              onTap: () {},
            ),
          ),
          Container(
            padding: EdgeInsets.only(left: 40, right: 40, bottom: 30),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Container(
                  child: InkResponse(
                    child: Text(
                      'Login ',
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 30),
                    ),
                    onTap: () {},
                  ),
                ),
                Container(
                  height: 55,
                  width: 55,
                  decoration: BoxDecoration(
//                    borderRadius: BorderRadius.circular(20),
                    gradient: Gradients.redGradient,
                    shape: BoxShape.circle,
                  ),
                  child: IconButton(
//                    iconSize: 50,
                    icon: Icon(
                      Icons.arrow_forward,
                      color: Colors.white,
                      size: 40,
                    ),
                  ),
                )
              ],
            ),
          ),
          Container(
            padding: EdgeInsets.only(left: 40, right: 40, bottom: 30),
            alignment: Alignment.topRight,
            child: InkResponse(
              onTap: () {},
              child: Text(
                'Skip Login',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.only(left: 40, right: 40, bottom: 30),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                InkResponse(
                  onTap: () {
                    Navigator.pushNamed(context, '/signUp');
                  },
                  child: Text(
                    'Sign Up',
                    style: TextStyle(
                        decoration: TextDecoration.underline,
                        fontSize: 17,
                        fontWeight: FontWeight.bold,
                        color: Colors.pink[700]),
                  ),
                ),
                InkResponse(
                  onTap: () {},
                  child: Text(
                    'Forgot Password',
                    style: TextStyle(
                        decoration: TextDecoration.underline,
                        fontSize: 17,
                        fontWeight: FontWeight.bold,
                        color: Colors.grey[700]),
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}
