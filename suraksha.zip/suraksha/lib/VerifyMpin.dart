import 'package:flutter/material.dart';
import 'package:pin_entry_text_field/pin_entry_text_field.dart';
import 'package:suraksha/values/gradients.dart';

class VerifyMpin extends StatefulWidget {
  @override
  _VerifyMpinState createState() => _VerifyMpinState();
}

class _VerifyMpinState extends State<VerifyMpin> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Container(
            padding: EdgeInsets.only(top: 30),
            decoration: BoxDecoration(
//            color: Color.fromRGBO(231, 10, 37, 2),
                gradient: Gradients.redGradient),
            child: Column(
              children: <Widget>[title(), mpinBody()],
            ),
          ),
        ),
      ),
    );
  }

  Widget title() {
    return Container(
      alignment: Alignment.center,
      child: (Column(
        children: <Widget>[
          Text(
            'Suraksha',
            style: TextStyle(
//              backgroundColor: Colors.grey,
                color: Colors.white,
                fontSize: 40,
                fontWeight: FontWeight.w900),
          ),
          Text(
            'Diagnostics',
            style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.w900,
                letterSpacing: 5),
          ),
          SizedBox(
            height: 0,
          ),
          Container(
//            color: Colors.grey,
              height: 190,
              width: 250,
              child: Image.asset(
                "assets/mpin.png",
                fit: BoxFit.contain,
              )),
        ],
      )),
    );
  }

  Widget mpinBody() {
    int num1=0;
    return Container(
      padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
      decoration: BoxDecoration(

          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(40), topRight: Radius.circular(40)),
          color: Colors.white),
      child: Container(
        height: 200,
        decoration: BoxDecoration(
          color: Color.fromRGBO(255, 240, 240, 1),
          borderRadius: BorderRadius.only(topLeft: Radius.circular(40), topRight: Radius.circular(40),bottomRight:Radius.circular(40), bottomLeft: Radius.circular(40)

        )
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//          mainAxisSize: MainAxisSize.min,
          children: <Widget>[

            Text('Enter MPIN',style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold),),
            Text('Please enter your pin to proceed',style: TextStyle(fontSize: 14, color: Colors.grey)),
            PinEntryTextField(
              showFieldAsBox: true,

//              fieldWidth: 12,
            ),
          ],
        ),
      )
    );
  }
}
