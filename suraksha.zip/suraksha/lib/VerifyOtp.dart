import 'dart:async';

import 'package:flutter/material.dart';
import 'package:suraksha/Timer.dart';
import 'package:suraksha/values/gradients.dart';

class VerifyOtp extends StatefulWidget {
  @override
  _VerifyOtpState createState() => _VerifyOtpState();
}

class _VerifyOtpState extends State<VerifyOtp> with SingleTickerProviderStateMixin{

  int time = 30;

  int num1, num2, num3, num4, currentDigit;

  AnimationController _controller;
  Map data = {};

  Timer timer;

//  int totalTimeInSeconds;
  bool _hideResendButton;


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _controller =
    AnimationController(vsync: this, duration: Duration(seconds: time))
      ..addStatusListener((status) {
        if (status == AnimationStatus.dismissed) {
          setState(() {
            _hideResendButton = !_hideResendButton;
          });
        }
      });
    _controller.reverse(
        from: _controller.value == 0.0 ? 1.0 : _controller.value);
    _startCountdown();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Stack(
          children: <Widget>[
            Container(
              height: 700,
              color: Color.fromRGBO(255, 246, 246, 1),
            ),


                ClipPath(
                  clipper: ClippingClass(),
                  child: Container(
                color: Color.fromRGBO(255, 236, 236, 1),
                      height: 320,
                      width: MediaQuery.of(context).size.width,
                  ),
                ),
              Container(
                padding: EdgeInsets.all(20),
                child: form(),
              ),
          ],
        ),
      ),
    );
  }

  Widget form() {

    return Container(
      padding: EdgeInsets.all(20),
      child:  Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          _verifyOtpLabel,

          Text(
            'Please enter the verification code sent to ',
            style: TextStyle(
                fontSize: 15.0,
                color: Colors.black
            ),
          ),
          Text(
            '0987654321',
            style: TextStyle(
                fontSize: 15.0,
                color: Colors.black
            ),
          ),

          SizedBox(height: 30,),

          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              _otpTextField(num1),
              SizedBox(width: 10,),
              _otpTextField(num2),
              SizedBox(width: 10,),
              _otpTextField(num3),
              SizedBox(width: 10,),
              _otpTextField(num4)
            ],
          ),

          SizedBox(height: 50,),
          _otpResend(),
          SizedBox(height: 30,),

          _otpKeyPad(),
        ],
      ),
    );
  }


  get _verifyOtpLabel {
    return Padding(
      padding: const EdgeInsets.fromLTRB(0,50,20,50),
      child: Text(
        'Verify OTP',
        style: TextStyle(
          fontSize: 22.0,
          letterSpacing: 3.0,
          fontWeight: FontWeight.bold
        ),
      ),
    );
  }

  Widget _otpTextField(int digit) {
    return new Container(
      width: 35.0,
      height: 45.0,
      alignment: Alignment.center,
      child: _fillText(digit),
//        child: Image.asset(
//          "assets/images/path.png",
//          fit: BoxFit.none,
//        )
//      child: new Text(
//        digit != null ? digit.toString() : "",
//
//        style: new TextStyle(
//          fontSize: 30.0,
//          color: Colors.black,
//        ),
//      ),
      decoration: BoxDecoration(
          border: Border(
              bottom: BorderSide(
                width: 1.0,
                color: Colors.grey,
              ))),
    );
  }

  Widget _fillText(int digit) {
    if (digit != null) {
      return new Text(
        digit != null ? digit.toString() : "",

        style: new TextStyle(
          fontSize: 30.0,
          color: Colors.black,
        ),
      );
    } else {
      return Container(
          height: 10.0,
          width: 10.0,
          decoration:BoxDecoration(
              color: Colors.grey[350],
              shape: BoxShape.circle
          ));
//      return Image.asset(
//            "assets/images/path.png",
//            fit: BoxFit.none,
//          );
    }

  }

  Widget _otpKeyboardInputButton({String label, VoidCallback onPressed}) {
    return new Container(
      child: InkResponse(
        onTap: onPressed,

        child: Container(
          padding: EdgeInsets.all(15),
          child: Text(
            label,
            style: new TextStyle(
                fontSize: 32.0,
                color: Colors.black
            ),
          ),
        ),
      ),
    );
  }

  Widget _otpKeyboardActionButton({Widget label, VoidCallback onPressed}) {
    return new Container(
      child: InkResponse(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(40.0),
        child: Container(
          child: label,
        ),
      ),
    );
  }

  Widget _otpKeyPad() {
    return Container(

      child: new Column(

        children: <Widget>[

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              _otpKeyboardInputButton(label: '1', onPressed: () {
                _setCurrentDigit(1);
              }),
              _otpKeyboardInputButton(label: '2', onPressed: () {
                _setCurrentDigit(2);
              }),
              _otpKeyboardInputButton(label: '3', onPressed: () {
                _setCurrentDigit(3);
              })
            ],
          ),

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              _otpKeyboardInputButton(label: '4', onPressed: () {
                _setCurrentDigit(4);
              }),
              _otpKeyboardInputButton(label: '5', onPressed: () {
                _setCurrentDigit(5);
              }),
              _otpKeyboardInputButton(label: '6', onPressed: () {
                _setCurrentDigit(6);
              })
            ],
          ),

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              _otpKeyboardInputButton(label: '7', onPressed: () {
                _setCurrentDigit(7);
              }),
              _otpKeyboardInputButton(label: '8', onPressed: () {
                _setCurrentDigit(8);
              }),
              _otpKeyboardInputButton(label: '9', onPressed: () {
                _setCurrentDigit(9);
              })
            ],
          ),

          Row(

            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[

              _otpKeyboardActionButton(
                  label: Padding(
                    padding: const EdgeInsets.fromLTRB(0, 0, 4, 0),
                    child: Icon(Icons.backspace),
                  ),
                  onPressed: () {
                    setState(() {
                      if (num4 != null) {
                        num4 = null;
                      } else if (num3 != null) {
                        num3 = null;
                      } else if (num2 != null) {
                        num2 = null;
                      } else if (num1 != null) {
                        num1 = null;
                      }
                    });
                  }
              ),
              _otpKeyboardInputButton(label: '0', onPressed: () {
                _setCurrentDigit(0);
              }),
              Container(
                height: 35,
                width: 35,
                decoration: BoxDecoration(
//                    borderRadius: BorderRadius.circular(20),
                  gradient: Gradients.redGradient,
                  shape: BoxShape.circle,
                ),
                child: IconButton(
//                    iconSize: 50,
                  icon: Icon(
                    Icons.arrow_forward,
                    color: Colors.white,
                    size: 20,
                  ),
                ),
              )
//              SizedBox(width: 30, height: 15.0,),

            ],

          )
        ],
      ),
    );
  }

  void _setCurrentDigit(int i) {
    setState(() {
      currentDigit = i;
      if (num1 == null) {
        num1 = currentDigit;
      } else if (num2 == null) {
        num2 = currentDigit;
      } else if (num3 == null) {
        num3 = currentDigit;
      } else if (num4 == null) {
        num4 = currentDigit;
      }
    });
  }

  Widget _otpResend() {
    return Container(
      child: Center(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Didn\'t recieve the OTP?',
              style: TextStyle(
                  fontSize: 15.0,
                  color: Colors.grey[600]
              ),
            ),
            _hideResendButton ? _getTimerText : _getResendButton,
//            Padding(
//              padding: const EdgeInsets.all(8.0),
//              child: Text(
//                '00:30',
//                style: TextStyle(
//                  color: Colors.blue
//                ),
//              ),
//            )
          ],
        ),
      ),
    );
  }

  get _getTimerText {
    return Container(
      height: 32,
      child: new Offstage(
        offstage: !_hideResendButton,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
//            new Icon(Icons.access_time),
            new SizedBox(
              width: 5.0,
            ),
            OtpTimer(_controller, 15.0, Colors.blue)
          ],
        ),
      ),
    );
  }

  Future<Null> _startCountdown() async {
    setState(() {
      _hideResendButton = true;
//      totalTimeInSeconds = time;
    });
    _controller.reverse(
        from: _controller.value == 0.0 ? 1.0 : _controller.value);
  }

  get _getResendButton {
    return new InkWell(
      child: new Container(
//        height: 32,
//        width: 120,
        padding: EdgeInsets.all(5.0),

        alignment: Alignment.center,
        child: new Text(
          "Resend OTP",
          style:
          new TextStyle(fontWeight: FontWeight.bold, color: Colors.black),
        ),
      ),
      onTap: () {
        setState(() {
          _hideResendButton = true;
          _startCountdown();
        });
        // Resend you OTP via API or anything
      },
    );
  }


  Widget skipButton(){
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: <Widget>[
        InkResponse(
          child: Container(
            padding: EdgeInsets.fromLTRB(10, 0, 0, 0),
            child: Text(
              'Skip',
              style: TextStyle(
                  color: Color.fromRGBO(231, 10, 47, 1),
                  letterSpacing: 0.2,
                  fontWeight: FontWeight.w500,
                  fontSize: 16.0,
                  decoration: TextDecoration.underline
              ),
            ),
          ),
          onTap: () {},
        ),
      ],
    );
  }

}

class MyClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    var path=Path();
    /*
    path.lineTo(0, size.height);
//    path.lineTo(size.width, 0);
    path.lineTo(size.width/2, size.height);
//    path.moveTo(size.width/2, size.height);
//    path.lineTo(size.width/2, size.height);
//    path.lineTo(size.width, 0);
    path.quadraticBezierTo( size.width/2, (size.height*3)/4, size.width, (size.height*3)/4);

    path.lineTo(size.width, size.height/2);
    */

    path.cubicTo(size.width / 4, 3 * size.height / 4, 3 * size.width / 4, size.height / 4, size.width, size.height);

    return path;


  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) {
    // TODO: implement shouldReclip
    return false;
  }

}

class ClippingClass extends CustomClipper<Path>{
  @override
  Path getClip(Size size) {
    var path=Path();
    path.lineTo(0, size.height-40);
    path.quadraticBezierTo( size.width/8, size.height/2, size.width/2, size.height/2);
//    path.close();
    path.quadraticBezierTo( (size.width*7)/8, size.height/2, size.width, 40);

    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) {
    // TODO: implement shouldReclip
    return false;
  }

}

