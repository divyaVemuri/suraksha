import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
//import 'package:geolocator/geolocator.dart';

class MapDemo extends StatefulWidget {
  @override
  _MapDemoState createState() => _MapDemoState();
}

class _MapDemoState extends State<MapDemo> {

  GoogleMapController myController;

  List<Marker> markers=[];


  @override
  void initState() {

    // TODO: implement initState
    super.initState();
    markers.add(Marker(
      markerId: MarkerId('myMarker'),
      draggable: true,
      onTap: (){
        print('Marker tapped');
      },
      position: LatLng(13.0240, 77.6433),


    ));

//    markers.add(Marker(
//      markerId: MarkerId('Kalyan Nagar'),
//      draggable: false,
//      onTap: (){
//        print("Current location tapped");
//      },
//      position: LatLng(13.0240, 77.6433)
//    ));
  }


  @override
  Widget build(BuildContext context)  {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Container(
            height: MediaQuery.of(context).size.height,
              width: double.infinity,
              child: GoogleMap(
                mapType: MapType.normal,
                initialCameraPosition: CameraPosition(
                  target: LatLng(13.0240, 77.6433),
                  zoom: 15
                ),
                markers: Set.from(markers),


//                onMapCreated: (controller){
//                  setState(() {
//                    myController=controller;
//                  });
//
//                },


              ),
            ),
            FlatButton(
              onPressed: myController==null?null:(){
              },
            )
          ],
        ),
      ),
    );
  }

}
