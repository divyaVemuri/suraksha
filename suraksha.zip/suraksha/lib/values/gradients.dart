
import 'package:flutter/rendering.dart';


class Gradients {
  static const Gradient primaryGradient = LinearGradient(
    begin: Alignment(0.5, 0),
    end: Alignment(0.5, 1),
    stops: [
      0,
      1,
    ],
    colors: [
      Color.fromARGB(255, 70, 152, 223),
      Color.fromARGB(255, 48, 115, 210),
    ],
  );

  static const Gradient redGradient = LinearGradient(
    begin: Alignment(5, -10),
    end: Alignment(0.5, 1),
//    begin: Alignment(-1, 0.5),
//    end: Alignment(0.5, 0.5),
    stops: [
      0,
      1,
    ],
    colors: [
      Color.fromARGB(255, 222, 0, 65),
      Color.fromARGB(255, 191, 0, 36),

    ],
  );

  static const Gradient greyGradient = LinearGradient(
//    begin: Alignment(0.5, 0),
//    end: Alignment(0.5, 1),
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    stops: [
      0,
      1,
    ],
    colors: [
      Color.fromARGB(255, 192, 196, 202),
      Color.fromARGB(255, 240, 245, 252),
    ],
  );



}
