import 'package:flutter/material.dart';
import 'package:suraksha/values/gradients.dart';

class MpinSuccessful extends StatefulWidget {
  @override
  _MpinSuccessfulState createState() => _MpinSuccessfulState();
}

class _MpinSuccessfulState extends State<MpinSuccessful> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          width: MediaQuery.of(context).size.width,
            color: Colors.white,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                SizedBox(height: 90),
                image(),
                SizedBox(height: 30),

                message(),
                SizedBox(height: 50),

                continueButton(context)],

          ),
        ),
      ),
    );
  }

  Widget image() {
    return Container(
        height: 190,
        width: 250,
        child: Image.asset(
          "assets/mpinSuccess.png",
          fit: BoxFit.contain,
        ));
  }

  Widget message() {
    return Container(
        child: Column(children: <Widget>[
      RichText(
        text: TextSpan(
          children: [
            TextSpan(
                text: 'MPIN',
                style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                    fontSize: 18)),
            TextSpan(
                text: ' Set successfully',
                style: TextStyle(color: Colors.black, fontSize: 18))
          ],
        ),
      ),
      SizedBox(height: 10,),
      Text(
        'Your MPIN has been set successfully.',
        style: TextStyle(
            fontSize: 12,
            color: Colors.black,
            decoration: TextDecoration.none,
            fontWeight: FontWeight.w200),
      )
    ]));
  }

  Widget continueButton(BuildContext context){
    return   InkResponse(
        child: Container(
//          padding: EdgeInsets.fromLTRB(30, 10, 30, 10),
          height: 50,
          width: MediaQuery.of(context).size.width-90,
          margin: EdgeInsets.symmetric(horizontal: 5),
          decoration: BoxDecoration(
            gradient: Gradients.redGradient,
            borderRadius: BorderRadius.all(Radius.circular(25)),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "Sign In with OTP",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color.fromARGB(255, 255, 255, 255),
                  fontFamily: "Avenir Next",
                  fontWeight: FontWeight.w600,
                  fontSize: 16,
                ),
              ),
            ],
          ),
        ),
        onTap: () {
        },
      );

  }
}
