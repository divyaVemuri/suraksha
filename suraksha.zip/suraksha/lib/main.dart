import 'package:flutter/material.dart';
import 'package:suraksha/Login.dart';
import 'package:suraksha/Map.dart' as prefix0;
import 'package:suraksha/MapDemo.dart';
import 'package:suraksha/MpinSuccessful.dart';
import 'package:suraksha/Register.dart';
import 'package:suraksha/SetMpin.dart';
import 'package:suraksha/VerifyMpin.dart';
import 'package:suraksha/VerifyOtp.dart';

void main() => runApp(MaterialApp(

  routes: {
    '/':(context)=>MapDemo(),
    '/signUp':(context)=>Register(),
    '/mpinSuccessful':(context)=>MpinSuccessful(),
    '/verifyOtp':(context)=>VerifyOtp()
  },
));
/*

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Geolocation Google Maps Demo',
      home: MyMap(),
    );
  }
}

class MyMap extends StatefulWidget {
  @override
  State<MyMap> createState() => MyMapSampleState();
}

class MyMapSampleState extends State<MyMap> {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      body: GoogleMap(
        mapType: MapType.hybrid,
        initialCameraPosition: CameraPosition(
          target: LatLng(40.688841, -74.044015),
          zoom: 11,
        ),
      ),
    );
  }
}*/
